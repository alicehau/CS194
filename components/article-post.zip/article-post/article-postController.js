'use strict';

cs142App.controller('ArticlePostController', ['$scope', '$routeParams', '$location',
  function($scope, $routeParams, $location) {
    /*
     * Since the route is specified as '/photos/:userId' in $routeProvider config the
     * $routeParams  should have the userId property set with the path from the URL.
     */
    $scope.main = {};
    $scope.addArticle = function() {
      //form fields bound to $scope
      $scope.articleTitle = '';
      $scope.articleLink = '';
      var createPost = $resource("/posts");
      createPost.save($scope.main.newUser, function(data) {
        $scope.main.errorMessage = "Welcome, " + data.first_name + "!";
        $scope.main.newUser = {
          first_name: "",
          last_name: "",
          login_name: "",
          location: "",
          description: "",
          occupation: "",
          password: "",
          passwordReentry: ""
        };
    }


    // $scope.FetchModel("/user/" + userId, $scope.main.callBackUser);

  }
]);
